<?php
//Config Database
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'beastsmm');
define('TIMEZONE', 'Asia/Karachi');
define('ENCRYPTION_KEY', 'a88e58da0f8c66f928fcd6aa73333fd0');