<?php if (get_role("admin")): ?>
<style>
  /* Container */
  #api-provider-balance-card.summary-card {
    margin-top: 20px;
    border: 1px solid #e8edf3;
    border-radius: 14px;
    padding: 16px 18px 18px;
    box-shadow: 0 6px 18px rgba(26, 46, 85, 0.08);
    background: #fff;
  }

  /* Header */
  #api-provider-balance-card h4 {
    margin: 0;
    font-size: 1.05rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
  }
  #api-provider-balance-card #refresh-balance-btn {
    margin: 0;
    white-space: nowrap;
  }

  /* Form */
  #api-provider-balance-card .form-group {
    margin-top: 12px;
    margin-bottom: 0;
  }
  #api-provider-balance-card label {
    font-weight: 600;
    font-size: 0.95rem;
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 6px;
  }
  #api-provider-balance-card #api-provider-select {
    max-width: 100%;
    width: 100%;
    min-height: 38px;
    font-size: 0.95rem;
  }
  #api-provider-balance-card #loading-live-indicator {
    font-weight: 500;
  }

  /* Balance */
  #api-provider-balance-card #balance-display {
    margin-top: 14px;
  }
  #api-provider-balance-card #balance-value {
    color: #16a085;
    font-size: 1.9rem;
    font-weight: 800;
    margin: 0;
    line-height: 1.2;
  }
  #api-provider-balance-card #session-indicator {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-top: 6px;
    color: #7f8c8d;
    font-size: 0.9rem;
  }

  /* Mobile tweaks */
  @media (max-width: 576px) {
    #api-provider-balance-card.summary-card {
      padding: 14px 14px 16px;
      border-radius: 12px;
    }
    #api-provider-balance-card h4 {
      font-size: 1rem;
      flex-direction: column;
      align-items: flex-start;
      gap: 8px;
    }
    #api-provider-balance-card #refresh-balance-btn {
      width: 100%;
      text-align: center;
    }
    #api-provider-balance-card label {
      font-size: 0.92rem;
    }
    #api-provider-balance-card #balance-value {
      font-size: 1.6rem;
    }
    #api-provider-balance-card #session-indicator {
      font-size: 0.85rem;
    }
  }
</style>

<!-- API Provider Balance Card -->
<div id="api-provider-balance-card" class="card summary-card">
  <h4>
    <?=lang("API Provider Balance")?>
    <button id="refresh-balance-btn" class="btn btn-sm btn-outline-primary" title="Refresh Balance" aria-label="Refresh Balance">
      <i class="fe fe-refresh-cw"></i> <?=lang("Refresh")?>
    </button>
  </h4>

  <div class="form-group">
    <label for="api-provider-select">
      <?=lang("Select Provider")?> 
      <small id="loading-live-indicator" style="color:#3498db; display:none;">
        <i class="fe fe-loader"></i> <?=lang("Fetching live balances...")?>
      </small>
    </label>
    <select id="api-provider-select" class="form-control">
      <option value=""><?=lang("Loading providers...")?></option>
    </select>
  </div>

  <div id="balance-display">
    <p id="balance-value" class="summary-value">
      <?=lang("Select a provider")?>
    </p>
    <small id="session-indicator" style="display:none;">
      <i class="fe fe-check-circle"></i> <?=lang("Provider saved in session")?> 
      <span style="color:#27ae60;">(<?=lang("Live Balance")?>)</span>
    </small>
  </div>
</div>

<script>
$(document).ready(function() {
  const SESSION_KEY = 'selected_api_provider';
  const MSG_SELECT_PROVIDER = '<?=lang("Select a provider")?>';
  let providers = [];
  
  function loadProviders() {
    $('#loading-live-indicator').show();
    $.ajax({
      url: '<?=cn("order/get_api_providers_balance")?>',
      type: 'GET',
      dataType: 'json',
      success: function(response) {
        $('#loading-live-indicator').hide();
        if (response.status === 'success' && response.data) {
          providers = response.data;
          populateProviderDropdown();
          const savedProviderId = sessionStorage.getItem(SESSION_KEY);
          if (savedProviderId) {
            $('#api-provider-select').val(savedProviderId);
            displayBalance(savedProviderId);
          }
        } else {
          $('#api-provider-select').html('<option value=""><?=lang("No providers available")?></option>');
        }
      },
      error: function() {
        $('#loading-live-indicator').hide();
        $('#api-provider-select').html('<option value=""><?=lang("Error loading providers")?></option>');
      }
    });
  }
  
  function populateProviderDropdown() {
    let options = '<option value="">-- <?=lang("Select Provider")?> --</option>';
    providers.forEach(function(provider) {
      const escapedIds = $('<div>').text(provider.ids).html();
      const escapedName = $('<div>').text(provider.name).html();
      options += '<option value="' + escapedIds + '">' + escapedName + '</option>';
    });
    $('#api-provider-select').html(options);
  }
  
  function displayBalance(providerIds) {
    const provider = providers.find(p => p.ids === providerIds);
    if (provider) {
      const balance = parseFloat(provider.balance);
      const balanceFormatted = isNaN(balance) ? '0.00' : balance.toFixed(2);
      const currency = provider.currency_code || '$';
      $('#balance-value').text(currency + ' ' + balanceFormatted).css('color', '#16a085');
      $('#session-indicator').show();
    } else {
      $('#balance-value').text(MSG_SELECT_PROVIDER).css('color', '#7f8c8d');
      $('#session-indicator').hide();
    }
  }
  
  $('#api-provider-select').on('change', function() {
    const selectedProviderId = $(this).val();
    if (selectedProviderId) {
      sessionStorage.setItem(SESSION_KEY, selectedProviderId);
      displayBalance(selectedProviderId);
    } else {
      sessionStorage.removeItem(SESSION_KEY);
      $('#balance-value').text(MSG_SELECT_PROVIDER).css('color', '#7f8c8d');
      $('#session-indicator').hide();
    }
  });
  
  $('#refresh-balance-btn').on('click', function() {
    const selectedProviderId = $('#api-provider-select').val();
    if (!selectedProviderId) {
      if (typeof notify === 'function') notify('error', '<?=lang("Please select a provider first")?>');
      else alert('<?=lang("Please select a provider first")?>');
      return;
    }
    const $btn = $(this);
    const originalHtml = $btn.html();
    $btn.html('<i class="fe fe-loader"></i> <?=lang("Refreshing...")?>')
        .prop('disabled', true)
        .attr('aria-busy', 'true');
    
    $.ajax({
      url: '<?=cn("order/refresh_provider_balance")?>',
      type: 'POST',
      data: {
        provider_ids: selectedProviderId,
        '<?=$this->security->get_csrf_token_name()?>': '<?=$this->security->get_csrf_hash()?>'
      },
      dataType: 'json',
      success: function(response) {
        if (response.status === 'success') {
          const provider = providers.find(p => p.ids === selectedProviderId);
          if (provider) {
            provider.balance = response.balance;
            provider.currency_code = response.currency_code;
            displayBalance(selectedProviderId);
          }
          if (typeof notify === 'function') notify('success', '<?=lang("Balance refreshed successfully")?>');
        } else {
          if (typeof notify === 'function') notify('error', response.message || '<?=lang("Failed to refresh balance")?>');
          else alert(response.message || '<?=lang("Failed to refresh balance")?>');
        }
      },
      error: function() {
        if (typeof notify === 'function') notify('error', '<?=lang("Error refreshing balance")?>');
        else alert('<?=lang("Error refreshing balance")?>');
      },
      complete: function() {
        $btn.html(originalHtml)
            .prop('disabled', false)
            .attr('aria-busy', 'false');
      }
    });
  });
  
  loadProviders();
});
</script>
<?php endif; ?>