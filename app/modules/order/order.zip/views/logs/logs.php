<?php if (get_option('orders_text','') != '') { ?>
<div class="col-sm-12 col-sm-12">
  <div class="row">
    <div class="card">
      <div class="card-body">
        <?=get_option('orders_text','')?>
      </div>
    </div>
  </div>
</div>
<?php }?>
<div class="container-fluid">
<div class="search-box m-r-30 d-none d-lg-block">
    <?php
    if ( allowed_search_bar(segment(1)) || allowed_search_bar(segment(2)) ) {
    echo Modules::run("blocks/search_box");
    }
    ?>
</div>
<br>
<div class="page-options d-flex">
    <ul class="list-inline mb-0 order_btn_group">
        <li class="list-inline-item">
            <a class="nav-link btn <?=($order_status == 'all') ? 'btn-info active1' : ''?>" href="<?=cn($module."/log/all")?>"><?=lang('All')?></a>
        </li>
        <?php 
        $status_array = order_status_array();
        if (!empty($status_array)) {
            foreach ($status_array as $row_status) {
                if ((get_role('user')) && in_array($row_status, ['error'])) {
                    continue;
                }
        ?>
        <li class="list-inline-item">
            <a class="nav-link btn <?=($order_status == $row_status) ? 'btn-info active1' : ''?>" href="<?=cn($module."/log/".$row_status)?>">
                <?=order_status_title($row_status)?>
                <?php
                    if (in_array($row_status, ['error']) && isset($number_error_orders)) {
                        echo '<span class="badge badge-danger badge-error-orders">'.$number_error_orders.'</span>';
                    }
                ?>
            </a>
        </li>
        <?php }}?>
    </ul>
</div>

<?php if ($order_status == 'all' && get_role("admin")): ?>
  <!-- Total Profit Card -->
  <div id="total-profit-card" class="card" style="margin-top: 20px; padding: 15px; border: 1px solid #ccc; border-radius: 5px; text-align: center;">
    <h4><?=lang("Total Profit")?></h4>
    <p id="total-profit-value" style="font-size: 18px; color: #2ecc71; font-weight: bold;">
      <!-- Total profit value will be inserted here -->
    </p>
  </div>

  <!-- Total Sell Card -->
  <div id="total-sell-card" class="card" style="margin-top: 20px; padding: 15px; border: 1px solid #ccc; border-radius: 5px; text-align: center;">
    <h4><?=lang("Total Sell")?></h4>
    <p id="total-sell-value" style="font-size: 18px; color: #f39c12; font-weight: bold;">
      <!-- Total sell value will be inserted here -->
    </p>
  </div>
<?php endif; ?>

</div>
<br>
<br>
<?php if ($order_status == 'error') { ?>
  <div class="dropdown d-inline-block">
    <button class="btn btn-secondary dropdown-toggle" type="button" id="bulkActionDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      Bulk Actions
    </button>
    <div class="dropdown-menu" aria-labelledby="bulkActionDropdown">
      <!-- Resend All Link -->
      <a class="dropdown-item" href="<?=cn("$module/change_status/resend_order/bulk")?>">
        Resend All
      </a>
      <!-- Cancel All Link -->
      <a class="dropdown-item" href="<?=cn("$module/change_status/cancel_order/bulk")?>">
        Cancel All
      </a>
    </div>
  </div>
<?php } ?>



<div class="row" id="result_ajaxSearch">
  <?php if(!empty($order_logs)){
  ?>
<div class="col-md-12">
  <div class="">
  <div class="card-header bg-gradient text-white">
    <!-- <div class="card-header" style="border: 0.1px solid #04a9f4; border-radius: 3.5px 3.5px 0px 0px; background: #04a9f4;"> -->
        <h3 style="color: #fff; text-align: center;" class="card-title"><?=lang("Your Orders")?></h3>
        <div class="card-options">
            <!-- Check if the user is admin -->
            <?php if (get_role("admin")) { ?>
            <!-- Dropdown for Export and Copy All API Order IDs -->
            <div class="dropdown">
                <button type="button" class="btn btn-outline-info dropdown-toggle" data-toggle="dropdown" style="background-color: #06324e; color: #fff; border: none;">
                    <i class="fa fa-clone mr-2"></i> <!-- Font Awesome icon for Copy -->
                    Copy Options
                </button>

                <div class="dropdown-menu" style="background-color: #051d2f!important; border: 1px solid #04a9f4;">
                    <a class="dropdown-item" href="#" onclick="copyAllApiOrderIds()" style="background-color: #051d2f!important; color: #fff !important;">
                        <i class="fa fa-copy mr-2"></i> Copy All API Order IDs
                    </a>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>

      <div class="table-responsive">
        <table class="table table-hover table-bordered table-vcenter card-table">
          <thead style="color: #fff;">
            <tr>
              <?php if (!empty($columns)) {
                foreach ($columns as $key => $row) {
              ?>
              <th><?=$row?></th>
              <?php }}?>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($order_logs)) {
              $currency_symbol = get_option("currency_symbol","");
              $decimal_places = get_option('currency_decimal', 2);
              switch (get_option('currency_decimal_separator', 'dot')) {
                case 'dot':
                  $decimalpoint = '.';
                  break;
                case 'comma':
                  $decimalpoint = ',';
                  break;
                default:
                  $decimalpoint = '';
                  break;
              }

              switch (get_option('currency_thousand_separator', 'comma')) {
                case 'dot':
                  $separator = '.';
                  break;
                case 'comma':
                  $separator = ',';
                  break;
                case 'space':
                  $separator = ' ';
                  break;
                default:
                  $separator = '';
                  break;
              }
              $i = 0;
              foreach ($order_logs as $key => $row) {
              $i++;
            ?>
            <tr style="color: #fff;" class="tr_<?=$row->ids?>">
            <td style="color: #fff;">
    <span id="orderId_<?=$row->id?>"><?=$row->id?></span> <!-- Display the Order ID -->
    <button onclick="copyToClipboard('orderId_<?=$row->id?>')" style="background:none; border:none; cursor:pointer;">
      <i class="fa fa-copy" style="color: #2ecc71; margin-left: 8px;"></i> <!-- Font Awesome Copy Icon -->
    </button>
  </td>


              <?php
                if (get_role("admin") || get_role("supporter")) {
              ?>
              <td class="text-center" style="color: #fff;">
            <span id="apiOrderId_<?=$row->id?>">
                <?= ($row->api_order_id == 0 || $row->api_order_id == -1) ? "" : $row->api_order_id ?>
            </span>
            <!-- Copy to clipboard button for API Order ID -->
            <?php if ($row->api_order_id != 0 && $row->api_order_id != -1): ?>
                <button onclick="copyToClipboard('apiOrderId_<?=$row->id?>')" style="background:none; border:none; cursor:pointer;">
                    <i class="fa fa-copy" style="color: #2ecc71; margin-left: 8px;"></i> <!-- Font Awesome Copy Icon -->
                </button>
            <?php endif; ?>
        </td>

              
              <td style="color: #fff;"><?=$row->user_email?></td>
              <?php } ?>
              <td>
                <div class="title" style="color: #fff; font-size: 13px;
  font-weight: 400;">
                  <h6><?=$row->service_id." - ".$row->service_name?></h6>
                </div>
                <div style="margin-left:5px !important">
                  <small>
                    <ul style="color: #fff;" style="margin:0px">
                      <?php
                        if (get_role("admin")) {
                      ?>
                      <li style="color: #fff;">
                        <?php echo lang("Type")?>: 
                        <?php 
                          if (!empty($row->api_service_id) && $row->api_service_id != "") {
                            if ($row->type == 'api') {
                              echo $row->api_name." (ID".$row->api_service_id. ")" . ' <span class="badge badge-default">API</span>';
                            }else{
                              echo $row->api_name." (ID".$row->api_service_id. ")";
                            }
                          }else{
                            echo lang("Manual");
                          }
                        ?>
                      </li>
                      <?php }?>

                      <li style="color: #fff;"><?=lang("Link")?>:
                        <?php
                          if (filter_var($row->link, FILTER_VALIDATE_URL)) {
                            echo '<a class="text-blue" href="'.$row->link.'" target="_blank">'.truncate_string($row->link, 60).'</a>'; 
                          } else {
                            echo truncate_string($row->link, 60);
                          }
                        ?>
                      </li> 
                      <li><?=lang("Quantity")?>: <?=$row->quantity?></li>
                      <?php 
// Initialize total profit and total sell variables (used for display purposes only)
$total_profit = 0;
$total_sell = 0;
?>

<!-- Table Rows -->
<li><?=lang("Charge")?>: 
  <?php 
    $usd_to_pkr_rate = 280; // Example conversion rate (1 USD = 280 PKR)
    
    echo $currency_symbol . currency_format($row->charge, $decimal_places, $decimalpoint, $separator);

    // Initialize profit variable
    $profit = 0;

    // Calculate profit if user is admin and valid charges are available
    if (get_role("admin") && is_numeric($row->charge) && is_numeric($row->formal_charge) && $row->charge > 0 && $row->formal_charge > 0) {
        $provider_charge_in_pkr = $row->formal_charge * $usd_to_pkr_rate;
        $profit = $row->charge - $provider_charge_in_pkr;
        $total_profit += $profit; // Add profit to total profit
    }

    // Add charge to total sell
    if (is_numeric($row->charge) && $row->charge > 0) {
        $total_sell += $row->charge; // Add charge to total sell
    }
  ?>
</li>

<li data-profit="<?= $profit ?>" data-charge="<?= $row->charge ?>"><?=lang("Provider Charge")?>: 
  <small style="color: #3498db; font-size: 12px;">
    <?= (isset($provider_charge_in_pkr) && $provider_charge_in_pkr > 0) 
         ? '$' . $row->formal_charge . ' (' . $currency_symbol . currency_format($provider_charge_in_pkr, $decimal_places, $decimalpoint, $separator) . ')' 
         : lang("No charge available"); ?>
  </small>
</li>

<li><?=lang("Start_counter")?>: <?=(!empty($row->start_counter)) ? $row->start_counter : lang("N/A")?></li>

<li><?=lang("Remains")?>: <?=(!empty($row->remains)) ? $row->remains : lang("N/A")?></li>

<?php
  $mention_list = get_list_custom_mention($row);
  if ($mention_list && $mention_list->exists_list) {
?>
<li><a href="<?=cn($module.'/ajax_show_list_custom_mention/'.$row->ids)?>" 
       class="btn btn-gray btn-sm ajaxModal btn-show-custom-mention"><?=$mention_list->title?></a></li>
<?php } ?>

<!-- Admin Section for Profit -->
<?php if (get_role("admin")): ?>
  <td>
    <?= $currency_symbol . currency_format($profit ?? 0, $decimal_places, $decimalpoint, $separator); ?>
  </td>
<?php endif; ?>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    // Initialize total profit and total sell variables
    let totalProfit = 0;
    let totalSell = 0;

    // Get all elements with data-profit and data-charge attributes
    const profitElements = document.querySelectorAll('li[data-profit]');
    const chargeElements = document.querySelectorAll('li[data-charge]');

    // Loop through each profit element and sum the profit values
    profitElements.forEach((element) => {
      let profit = parseFloat(element.getAttribute('data-profit'));
      if (!isNaN(profit)) {
        totalProfit += profit;
      }
    });

    // Loop through each charge element and sum the charge values
    chargeElements.forEach((element) => {
      let charge = parseFloat(element.getAttribute('data-charge'));
      if (!isNaN(charge)) {
        totalSell += charge;
      }
    });

    // Round total profit and total sell to avoid floating-point precision errors
    totalProfit = Math.round(totalProfit * 10000) / 10000; // Round to 4 decimal places
    totalSell = Math.round(totalSell * 10000) / 10000; // Round to 4 decimal places

    // Store the total profit and total sell in localStorage
    localStorage.setItem('totalProfit', totalProfit);
    localStorage.setItem('totalSell', totalSell);

    // Function to display the total profit in an existing card
    function displayTotalProfit(profit) {
      const totalProfitCard = document.getElementById('total-profit-card');
      if (totalProfitCard) {
        totalProfitCard.innerHTML = `
          <h4>Total Profit <small style="font-size:12px">(100 orders)</small></h4>
          <p style="font-size: 18px; color: #2ecc71; font-weight: bold;">
            ${profit.toFixed(4)} PKR
          </p>
        `;
      }
    }

    // Function to display the total sell in an existing card
    function displayTotalSell(sell) {
      const totalSellCard = document.getElementById('total-sell-card');
      if (totalSellCard) {
        totalSellCard.innerHTML = `
          <h4>Total Sell <small style="font-size:12px">(100 orders)</small></h4>
          <p style="font-size: 18px; color: #f39c12; font-weight: bold;">
            ${sell.toFixed(4)} PKR
          </p>
        `;
      }
    }

    // Display the total profit and total sell cards
    displayTotalProfit(totalProfit);
    displayTotalSell(totalSell);
  });
</script>

              <td style="color: #fff;"><?=convert_timezone($row->created, "user")?></td>
              <td>
                <?php
                  $order_status = $row->status;
                  if (!get_role('admin') && in_array($order_status, ['fail', 'error'])) {
                    $order_status = 'processing';
                  }
                  if ($order_status == "pending" || $order_status == "processing") {
                    $btn_background = "btn-info";
                  }elseif ($order_status == "inprogress") {
                    $btn_background = "btn-orange";
                  }elseif($order_status == "completed"){
                    $btn_background = "btn-blue";
                  }else{
                    $btn_background = "btn-danger";
                  }
                ?>
                <span class="btn round btn-sm <?=$btn_background?>"><?php echo order_status_title($order_status)?></span>
              </td>

                    <td>
                      <?php
                      $datetime = date_create($row->created);
                      $datetimenow = date_create(date("Y-m-d H:i:s"));
                      $diff = date_diff($datetime, $datetimenow);
                      $curr_diff = $diff->format("%a");
                      $def_diff = get_option('refill_expiry_days', 30);
                      ?>
                      <?php if ($row->is_refill == "yes") { ?>
                        <?php if ($row->refill_status == "no") { ?>
                          <?php if ($row->status == "completed") { ?>
                            <?php if ($curr_diff <= $def_diff) { ?>
                              <form class="form actionForm" action="<?= cn($module . "/refill_order/$row->ids") ?>" data-redirect="<?= cn($module . "/log") ?>" method="POST">
                                <center><button type="submit" class="btn round btn-success">&nbsp;&nbsp;&nbsp;Refill&nbsp;&nbsp;&nbsp;</button></center>
                              </form>
                            <?php } else { ?>
                              <center><button disabled class="btn round btn-danger">Out of Refill Date</button></center>
                            <?php } ?>
                          <?php } else { ?>
                            <center><button type="submit" class="btn round btn-info">Order Pending</button></center>
                          <?php } ?>
                        <?php } elseif ($row->refill_status == "yes") { ?>
                          <center><button disabled class="btn round btn-info">Refill in progress</button></center>
                        <?php } elseif ($row->refill_status == "never") { ?>
                          <center><button disabled class="btn round btn-danger">No Longer Refillable</button></center>
                        <?php } ?>
                      <?php } else { ?>
                      <?php } ?>
                    </td>
                    
                    <?php
// Main logic to display the table
if (get_role("admin") || get_role("supporter")) {
?>
    <td class="text-red"><?=(empty($row->note))? "" : $row->note?></td>
    <td class="text-center">
        <a href="<?=cn("$module/log_update/".$row->ids)?>" class="ajaxModal">
            <i class="btn btn-info fe fe-edit"> <?=lang('Edit')?></i>
        </a> 
        <br><br>
        <?php
        if (get_role('admin')) {
            if ($row->status == 'error') {
                // Send email notification to admin
                sendErrorNotification($row->id, $row->note); // Pass order ID and note

                // Resend option
        ?>
                <a href="<?=cn("$module/change_status/resend_order/".$row->id)?>" class="">
                    <i class="btn btn-success fe fe-send"> Resend</i>
                </a>
                <br><br>
        <?php
            }
        }
        ?>
    </td>
<?php } ?>

            </tr>  
            <?php }}?>

          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-md-12">
    <div class="float-right">
      <?=$links?>
    </div>
  </div>
  <?php }else{
    echo Modules::run("blocks/empty_data");
  }?>
</div>
 

    <script>
$(document).ready(function() {
    // Add click event listener to the sidebar toggle button/icon
    $('.sidebar-toggle').click(function() {
        // Toggle the visibility of the sidebar by adding/removing a CSS class
        $('.sidebar').toggleClass('active');
    });
});

// Function to copy the content to clipboard
function copyToClipboard(elementId) {
  // Get the text from the specified element by its ID
  var textToCopy = document.getElementById(elementId).innerText;

  // Create a temporary textarea element to hold the text to copy
  var tempInput = document.createElement("textarea");
  tempInput.value = textToCopy;
  document.body.appendChild(tempInput);

  // Select the text in the textarea and copy it
  tempInput.select();
  tempInput.setSelectionRange(0, 99999); // For mobile devices
  document.execCommand("copy");

  // Remove the temporary textarea from the document
  document.body.removeChild(tempInput);

  // Optionally, you can show a notification or alert to the user
  alert("Order ID copied: " + textToCopy);
}

function copyAllApiOrderIds() {
    // Gather all API Order IDs
    let apiOrderIds = [];
    document.querySelectorAll('[id^="apiOrderId_"]').forEach(function(element) {
        if (element.textContent.trim() !== "") {
            apiOrderIds.push(element.textContent.trim());
        }
    });

    // Format the API Order IDs
    if (apiOrderIds.length > 0) {
        let formattedText = 'order ids\n' + apiOrderIds.join(',\n');
        
        // Copy to clipboard
        copyTextToClipboard(formattedText);
        alert("API Order IDs copied to clipboard!");
    } else {
        alert("No API Order IDs found to copy.");
    }
}

// Helper function to copy text to clipboard
function copyTextToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
}

</script>
