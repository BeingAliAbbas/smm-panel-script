<?php
//Config Database
define('DB_HOST', 'localhost');
define('DB_USER', 'beastsmm_ali');
define('DB_PASS', 'ra6efcTo[4z#');
define('DB_NAME', 'beastsmm_ali');
define('TIMEZONE', 'Asia/Karachi');
define('ENCRYPTION_KEY', 'a88e58da0f8c66f928fcd6aa73333fd0');